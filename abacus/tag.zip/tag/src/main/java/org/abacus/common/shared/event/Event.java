package org.abacus.common.shared.event;

public interface Event {

}
