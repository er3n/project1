package org.abacus.common.shared.event;

public class RequestReadEvent implements Event {
}
