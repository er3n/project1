package org.abacus.common.shared.event;

public abstract class UpdateEvent implements Event {
}
