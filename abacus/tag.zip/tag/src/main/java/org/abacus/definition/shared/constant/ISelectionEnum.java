package org.abacus.definition.shared.constant;


public interface ISelectionEnum {
	
	String getName();
	String getDescription();

}
