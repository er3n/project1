package org.abacus.transaction.shared.event;

import org.abacus.common.shared.event.DeletedEvent;
import org.abacus.transaction.shared.entity.TraDetailEntity;

public class DetailDeletedEvent<D extends TraDetailEntity> extends DeletedEvent {

}
